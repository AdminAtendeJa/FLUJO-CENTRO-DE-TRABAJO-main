const CLIENT_FIELDS = ['fecha', 'id_kommo', 'cpf', 'nombre', 'telefono', 'email', 'valor_total', 'pais', 'ciudad', 'estado_cliente', 'canal_adquisicion', 'atendente'];
const RECENT_DAYS = 7;

let supabaseClient = null;
let clients = [];
let activeTab = 'recent';
let editModalClientData = null;
let searchTerm = '';

function setStatus(state, text) {
  const badge = document.getElementById('statusBadge');
  if (!badge) return;
  badge.className = 'status-badge status-' + state;
  badge.textContent = text;
}

function safeText(value) {
  if (value === null || value === undefined) return '';
  return String(value);
}

function escapeHtml(value) {
  return safeText(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDateForInput(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : date.toISOString().slice(0, 10);
}

function getPrimaryKeyName(record) {
  const candidateKeys = ['id', 'uuid', 'uid', 'id_cliente', 'cliente_id', 'id_kommo'];
  return candidateKeys.find(key => {
    if (!Object.prototype.hasOwnProperty.call(record, key)) return false;
    const value = record[key];
    return value !== null && value !== undefined && String(value).trim() !== '';
  });
}

function getPrimaryKeyValue(record) {
  const key = getPrimaryKeyName(record);
  return key ? record[key] : null;
}

function getRecordByPrimaryKey(keyName, keyValue) {
  return clients.find(record => String(record[keyName]) === String(keyValue)) || null;
}

function isRecentClient(record) {
  // creado_en es más confiable — fecha puede ser null en clientes manuales
  const dateString = record.creado_en || record.fecha || record.created_at;
  if (!dateString) return false;
  const value = new Date(dateString);
  if (Number.isNaN(value.getTime())) return false;
  const diff = (Date.now() - value.getTime()) / (1000 * 60 * 60 * 24);
  return diff >= 0 && diff <= RECENT_DAYS;
}

function isKommoClient(record) {
  return safeText(record.id_kommo).trim() !== '';
}

function hasPendingStatus(record) {
  const status = safeText(record.estado_cliente).trim().toLowerCase();
  if (status === '' || status === 'nuevo') return true;
  return /pendiente|por validar|sin validar|espera|pending/.test(status);
}

function isRecentCandidate(record) {
  return hasPendingStatus(record) && isRecentClient(record);
}

function updateFilters() {
  searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
}

  function filterClients() {
  if (activeTab === 'all') return [...clients]; // <--- Agrega esto
  
  let rows = [...clients];
  if (activeTab === 'recent') {
    rows = rows.filter(isRecentCandidate);
  }
  if (searchTerm) {
    rows = rows.filter(record =>
      CLIENT_FIELDS.some(field => safeText(record[field]).toLowerCase().includes(searchTerm))
    );
  }
  return rows;
}
  

function buildCell(value, name) {
  return `<td><div>${escapeHtml(value)}</div></td>`;
}

function renderTable() {
  const container = document.getElementById('clientesTabla');
  const rows = filterClients();
  if (!container) return;

  if (!rows.length) {
    container.innerHTML = '<tr><td colspan="13" style="text-align:center; padding: 24px; color: #6b6b6b;">No se encontraron clientes para esta vista.</td></tr>';
    return;
  }

  container.innerHTML = rows.map(record => {
    const keyValue = getPrimaryKeyValue(record);
    const keyName = getPrimaryKeyName(record);
    const cells = CLIENT_FIELDS.map(field => buildCell(record[field], field)).join('');
    const badge = isKommoClient(record) ? '<span class="pill">Kommo</span>' : '';
    const pendingBadge = isRecentCandidate(record) ? '<span class="pill" style="background:#FEF3C7;color:#92400E;">Pendiente</span>' : '';
    const validatedBadge = !isRecentCandidate(record) && safeText(record.estado_cliente).trim() !== ''
      ? '<span class="pill pill-validated">Validado</span>'
      : '';
    const editButton = `<button type="button" class="button secondary" data-action="edit" data-key-name="${keyName}" data-key-value="${keyValue}">Editar</button>`;

    return `<tr data-key-name="${keyName}" data-key-value="${keyValue}">${cells}<td class="actions-cell">${badge}${pendingBadge}${validatedBadge}${editButton}</td></tr>`;
  }).join('');
}

function setActiveTab(tab) {
  activeTab = tab;
  document.querySelectorAll('.tab').forEach(button => {
    const isActive = button.dataset.tab === tab;
    button.classList.toggle('active', isActive);
  });
  renderTable();
}

async function fetchClients() {
  try {
    setStatus('loading', 'Cargando clientes...');
    const { data, error } = await supabaseClient
      .from('clientes')
      .select('*')
      .order('creado_en', { ascending: false, nullsFirst: false })
      .limit(5000);

    if (error) throw error;
    clients = data || [];
    renderTable();
    setStatus('live', 'Conectado');
  } catch (error) {
    console.error('fetchClientes error:', error);
    setStatus('error', error?.message || 'Error al cargar clientes');
  }
}

async function saveClient(keyName, keyValue, updates) {
  try {
    const record = getRecordByPrimaryKey(keyName, keyValue);
    if (!record) { setStatus('error', 'Cliente no encontrado'); return; }

    const isPending = /^(|pendiente|pendente|nuevo|novo|por validar|sin validar|espera|pending)$/i;
    if (isPending.test(safeText(record.estado).trim()) || isPending.test(safeText(updates.estado).trim())) {
      updates.estado = 'Validado';
    }

    if (updates.valor_total) {
      const parsed = Number(updates.valor_total.toString().replace(/[^0-9.,-]/g, '').replace(',', '.'));
      updates.valor_total = Number.isFinite(parsed) ? parsed : updates.valor_total;
    }

    const cleanedUpdates = {};
    Object.entries(updates).forEach(([field, value]) => {
      let v = typeof value === 'string' ? value.trim() : value;
      if (v === '') v = null;
      const orig = record[field] == null ? null : String(record[field]).trim();
      const nw = v === null ? null : String(v).trim();
      if (orig !== nw) cleanedUpdates[field] = v;
    });

    if (!Object.keys(cleanedUpdates).length) { setStatus('live', 'Sin cambios'); return; }

    const updateKey = record.id != null ? 'id' : keyName;
    const matchValue = updateKey === 'id' ? Number(record.id) : record[keyName] || keyValue;

    setStatus('loading', 'Guardando...');
    const { data: updatedRows, error } = await supabaseClient
      .from('clientes')
      .update(cleanedUpdates)
      .match({ [updateKey]: matchValue })
      .select();

    if (error) throw error;
    if (!updatedRows?.length) throw new Error('No se actualizó ningún registro');

    const idx = clients.indexOf(record);
    if (idx >= 0) clients[idx] = updatedRows[0];
    renderTable();
    setStatus('live', 'Guardado');
  } catch (error) {
    console.error('saveClient error:', error);
    setStatus('error', error?.message || 'Error al guardar');
  }
}

function openEditModal(record) {
  if (!record) return;
  const keyName = getPrimaryKeyName(record);
  const keyValue = record[keyName];
  if (!keyName || keyValue == null) return;

  editModalClientData = { keyName, keyValue, record };
  document.getElementById('editModalTitle').textContent = `Editar: ${safeText(record.nombre) || keyValue}`;
  
  const form = document.getElementById('editFormFields');
  form.innerHTML = CLIENT_FIELDS.map(field => {
    const label = field.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    const isDate = field === 'fecha';
    const val = isDate ? formatDateForInput(record[field]) : escapeHtml(record[field]);
    return `<div class="modal-field">
      <label class="modal-label" for="modal_${field}">${label}</label>
      <input id="modal_${field}" class="editable-input" name="${field}" type="${isDate ? 'date' : 'text'}" value="${val}">
    </div>`;
  }).join('');

  const modal = document.getElementById('editModal');
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden', 'false');
}

function closeEditModal() {
  document.getElementById('editModal').classList.add('hidden');
  document.getElementById('editModal').setAttribute('aria-hidden', 'true');
  editModalClientData = null;
}

function setupEvents() {
  document.getElementById('searchInput').addEventListener('input', () => {
    updateFilters();
    renderTable();
  });

  document.querySelectorAll('.tab').forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      setActiveTab(button.dataset.tab);
    });
  });

  document.getElementById('clientesTabla').addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button || button.dataset.action !== 'edit') return;
    const record = getRecordByPrimaryKey(button.dataset.keyName, button.dataset.keyValue);
    if (record) openEditModal(record);
  });

  document.getElementById('editModalClose').addEventListener('click', closeEditModal);
  document.getElementById('editModalCancel').addEventListener('click', closeEditModal);
  document.getElementById('editModal').addEventListener('click', e => {
    if (e.target === e.currentTarget) closeEditModal();
  });

  document.getElementById('editModalForm').addEventListener('submit', async event => {
    event.preventDefault();
    if (!editModalClientData) return;
    const { keyName, keyValue } = editModalClientData;
    const updates = {};
    document.querySelectorAll('#editModalForm input[name]').forEach(input => {
      updates[input.name] = input.value.trim();
    });
    await saveClient(keyName, keyValue, updates);
    closeEditModal();
  });
}

function setupRealtime() {
  supabaseClient.channel('clientes-realtime')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'clientes' }, fetchClients)
    .subscribe(status => {
      if (status === 'SUBSCRIBED') setStatus('live', 'En vivo');
      if (status === 'CHANNEL_ERROR') setStatus('error', 'Realtime desconectado');
    });
}

async function init() {
  try {
    const cfg = window.SUPABASE_CONFIG;
    if (!cfg?.url || !cfg?.anonKey || cfg.url.includes('__SUPABASE')) {
      setStatus('error', 'Configura Supabase en config.js');
      return;
    }
    if (!window.supabase?.createClient) {
      setStatus('error', 'No se cargó el SDK de Supabase');
      return;
    }
    supabaseClient = window.supabase.createClient(cfg.url, cfg.anonKey);
    setupEvents();
    await fetchClients();
    setActiveTab(activeTab);
    setupRealtime();
  } catch (error) {
    console.error('init error:', error);
    setStatus('error', error?.message || 'Error al inicializar');
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}